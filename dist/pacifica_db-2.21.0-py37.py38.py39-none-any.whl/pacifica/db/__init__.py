from pacifica import cli


def connect():
    return cli
